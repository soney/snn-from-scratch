import sys

print(sys.argv[1:])
