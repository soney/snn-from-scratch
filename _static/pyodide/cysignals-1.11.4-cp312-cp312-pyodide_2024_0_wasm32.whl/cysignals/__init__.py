from .signals import AlarmInterrupt, SignalError, init_cysignals  # noqa

init_cysignals()
