def write():
    raise Exception("not implemented")
