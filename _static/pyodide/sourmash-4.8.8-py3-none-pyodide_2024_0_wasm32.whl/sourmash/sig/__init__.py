from .__main__ import *  # bring all functions into top-level
from . import grep
